#           111111111122222222223333333333
# 0123456789012345678901234567890123456789
# !"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGH
# 
# $: contains the data for the bottom half of the candle, the bit that doesn't
# move.
$: = q^
       A"#,Z
       >1Z
       97Z
       5;Z
       5;Z
       5:Z
       5:Z
       5;Z
       4<Z
       3=Z
       3;Z
       3;Z
       68Z
       68Z
       68Z
       68Z
       68Z
       68Z
       68Z
       68Z
       68Z
       $"28Z
       !*-8)"&"Z
       #.'8#"%+Z
       $2"8$2Z
       $#$E#5Z
       *##-$DZ
       0%%1"$"#$"&"&"Z
       1"*'"&Z
       7/Z
       33Z
       13Z
       3$#$$$Z
      ^;

# $; and $^ contain the two alternate top halves.
$; = q^
       B"Z
       6"("Z
       <"*"Z
       1"%"*"-"Z
       H"Z
       ."'"("%"+"%"Z
       >#Z
       1"'"'$$"%"&"$"Z
       ,"3&Z
       3"+),"Z
       8"%*$"%"Z
       1",*Z
       >'#"$%Z
       7"%"%"&)Z
      ^;

$^ = q^
       @"Z
       8"*"Z
       ="*"Z
       2"&"*"*"Z
       F"Z
       /"%")"&")"%"Z
       >#Z
       2"'"&$%"%"$"$"Z
       -"2&Z
       4"*)+"Z
       7"&*%"#"Z
       0"-*Z
       >'$"#%Z
       6"%"&"&)Z
      ^;
;;

# define a sub "_"
sub  _ {

    # which gets rid of spaces in $_
    s}\s}}g;

    # $. is a "*", this is useful because:
    # $. ^ $/ eq " "
    # and of course, $. ^ $/ ^ $/ eq "*"
    $. = '*';

    # run "CLS" or "clear" depending on what system we're on.
    system
	$^O =~ Win ?
		 CLS : 
		 'clear';

    # note 3 different uses of $_ here:
    # 1. the global data
    # 2. that data split by "Z" from the for() below
    # 3. each character mapped to be the multiplier, when passed
    #    through ord() and then having 33 subtracted.
    #
    # so this prints alternate " " and "*" for each character in the data,
    # with "Z" marking line splits
    print + map ((( $. ^= $/ ) x ( ((ord)) -33) ) , /./g ), $/
	for + split +Z;

    ;

    # sleep "not 0" == 1
    sleep !$%
}

# this is a fake, the argument isn't used, but it's evaluated before the
# function is called. So, we call &_ with ($_ eq $; . $:), and then with
# ($_ eq $^ . $:), which we do 4 times each.
_ ( $_ = $; . $: ) , _ $_ = $^ . $: , for !$% .. 4;

# define a new string to print.
$_ = 'Merry60Christmas60to60a60snowbound60cam.pm60from60a60Sydney60sunbather!';

# make sure that print will automatically put a newline on the end.
$\ = $/;

# get rid of spaces in the above string
s;\s;;g;

;;;

# $= is our current format page length (defaults to 60). $" defaults to a
# space. The evaluation doesn't really matter, because it would get
# substituted anyway...
s;$=;$";gsex;

# print out the string
print;

# random filler noop substitution
s;k   ara
          te;chop                      ;eggs;;
