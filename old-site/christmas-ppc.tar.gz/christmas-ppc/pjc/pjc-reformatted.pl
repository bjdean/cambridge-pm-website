# $w=500 - The width and height of our canvas
$w = 100;
$w *= 5;
;

# $W=250000 = number of pixels
$W = $w*$w;

# ''
q--;

# $p = \pi
$p = atan2(1,0)*2;
3;

# fill each pixel with 0x000000
@P=("\000"x3) x ($W);

BEGIN {
    $";

    # $_ is going to be (lc only) rot-13'ed, and "d" is used as a space
    # separator so:

    # S adds "sub " to the code we're building
    sub S {
	$_ .= 'fhoq'
    }

    # K keeps track of a number, and adds "f<n>{" to the stream, where
    # <n> is replaced by an incrementing counter
    sub K {
	$_ .= 's' . (( $n++ )) . (('' . '' . '{' ));
    }

    ;

    # Y adds its argument onto the stream.
    sub Y {
	$_ .= $_ [0]
    }

    ;

    # sub f0{$x/=2;$y/=2}
    S;K;
    Y ( '' . '$k/=2;$' . '' . 'l/=2}');

    # sub f1{$x/=3;$y/=3;$x+=$w/4}sub u{pri "P6\n$w $w\n255\a", @P}
    # note that below the "i" gets expanded to "int"
    S;K;
    0;
    Y( '$k/=3;$l/=3;$k+=$j/4}fhoqh{' . '' . 'cevq"P6\a$jq$j\a255\a",q@P}');

    # sub f2{$t=$p/3;r}
    S;K;
    Y('$g=$c/3;e}');

    # sub f3{$t=$p/-3;r}
    S;K;
    Y(q.$g=$.  .'c/-3;'    .'e}');

    # sub f4{$t=$p*2/3}
    S;K;
    Y( '$' . 'g'. '=' . '$c*2' . '/3}');
    ;

    # turn "i" into "int"
    s/v/vag/x;

    # p turns a pixel ($x-$w/2 , $y-$w/2) to white
    # ie, the origin for x and y is in the middle
    sub p {
	$P[ $x + $w/2 + int($y)*$w + $W/2 ] = "\377" x 3
    }

    # r rotates the cursor vector by $t
    sub r {
	$z = $x * cos($t) + $y * sin($t);
	$y = $x * sin($t) - $y * cos($t);
	$x = $z
    }

    ;

    # rot13
    tr/a-z/n-za-m/;

    # substitute d (q before the rot) with " "
    s/d/$"/gx;

    $x++;
    $y=4;
    
    # the finished code that will be run is:
    #   # move the cursor closer in by a factor of 2
    #   sub f0 {
    #       $x /= 2;
    #       $y /= 2
    #   }
    #
    #   # f1 moves the cursor inwards by a factor of 3 (to the centre)
    #   # and then move it out by a quarter of the canvas along the x-axis
    #   # this gives a lot of the filament structure
    #   sub f1 {
    #       $x /= 3;
    #       $y /= 3;
    #       $x += $w/4
    #   }
    #
    #   # print out our canvas as a PPM
    #   sub u {
    #       print "P6\n$w $w\n255\n", @P
    #   }
    #
    #   # Theta = pi/3 ; rotate
    #   sub f2 {
    #       $t=$p/3;
    #       r
    #   }
    #
    #   # Theta = -pi/3 ; rotate
    #   sub f3 {
    #       $t = $p/-3;
    #       r
    #   }
    #
    #   # This does nothing
    #   sub f4 {
    #       $t = $p*2/3
    #   }

    eval $_
}

;
s/ /japh/;

sub T {
    ;
    # $a is our argument
    $a = $_[0];
    ;
    # $b > 0 if $a not element of [0,4]
    # I did this by doing:
    # perl -e 'map { $b=(($_ & (($_|($_<<1))<<1))>>2)|($_>>3); print "\$a=$_ \$b=$b\n" } (0..20)'

    $b=(( $a & (( $a | (+$a<<1) ) <<1 )) >> 2 ) | ( $a>>3 );

    if($b) {
	# note this is a reassign back to our argument
	# does nothing
	$_[0] = ""
    }
    else {
	# note this is a reassign back to our argument
	# calls f0,f1,f2,f3,f4 as appropriate, and then puts the pixel
	$_[0] = "f$a;p;"
    }
}

;;

# apply lots of potential transformations using T.
for(1 .. 20000*10) {
    $_ = int(rand(20));
    T $_;
    0;
    # since T reassigns back in its argument, we eval that
    eval $_
}

# u prints out the ppm
u
