($.,$;)=@ENV{LINES,COLUMNS};

$_='.2:2/5.=:2.69A..6:9D..6>.G;1.29J..6;.M;1.29P..6;'.
   '.S6..69V..0>.Z:2.69a..6>.d;1.29g..6;.j;1.29m..6;';

# $w is our framecounter
for $w (0..29) {
    # $# is our output variable, the first thing to do is to reset the
    # cursor to 0
    $#="\e[H";
    
    # $| starts off as 0, so:
    for($i=$.*2 ; $i ; --$i) {
	# this will get executed every second time through the loop
	# (there's no assign to $| anywhere else)
	# so on the 1st, 3rd, 5th iteration, set $@ to linewidth
	# spaces
	$@=(B^b) x $; if --$|;

	# $h has a (slightly shifted) inverse relationship to $i
	$h= $.*2 / ($.*2 -$i +1);

	# turn our data into something useful
	s/\s//g;

	# $v is a scaled version of $h
	$v=($h-1) * $./2;

	# our data is:
	# ( 0, 4,12, 4, 1, 7) ( 0,15,12, 4, 0, 8) (11,19, 0, 0, 8,12)
	# (11,22, 0, 0, 8,16) ( 0,25,13, 3, 0, 4) (11,28, 0, 0, 8,13)
	# ( 0,31,13, 3, 0, 4) (11,34, 0, 0, 8,13) ( 0,37, 8, 0, 0, 8)
	# (11,40, 0, 0, 2,16) ( 0,44,12, 4, 0, 8) (11,51, 0, 0, 8,16)
	# ( 0,54,13, 3, 0, 4) (11,57, 0, 0, 8,13) ( 0,60,13, 3, 0, 4)
	# (11,63, 0, 0, 8,13)

	while(/(.{6})/g) {
	    # actually do the read. This trick works because of the /g
	    # modifier, which means that the regexp keeps track of where
	    # the last match was.
	    ($t,$x,$y,$r,$k,$l)=map {$_-46} unpack c6,$1;
	    # for each datapoint
	    # $t is 0 for a circle and has a value for a rectangle
	    # $p is either the 5th or the 3rd digit
	    #   (The top of the object?)
	    $p=$t?$k:$y;
	    # $q is either the 6th or the 3rd digit
	    #   (The bottom of the object?)
	    $q=$t?$l:$y;
	    # $z is the 4th digit + 0.8
	    $z=$r+.8;

	    # this condition is true if the current scanline (represented
	    # by $v) is outside the bounding box of the object
	    next if $v<$w+$p-$z || $v>$w+$q+$z;

	    $y+=$w;

	    # note that the for implicitly localises the loop variable,
	    # so $_ at the end of the loop is our dataset
	    # iterate $_ over twice the width of the screen
	    for (0 .. $;*2-1) {
		# $u is a step in increments of $h*32/<width>, from
		# negative to positive.
		$u=($h*($_-$;)+$;) * 32/$; ;

		# don't do anything if we're to the left or to the right
		# of this object
		next if $u<$x-$z || $u>$x+$z;

		# if $t is 0 then it's a circle, rather than a rectangle,
		# so use it as one.
		if(!$t) {
		    # this is an ellipse formula at ($x,$y), but scaled by
		    # $u and $v in the x and y directions
		    $d=sqrt(($v-$y)**2 + ($u-$x)**2);

		    # draws if it's in the circle which has a hole in it.
		    next if $d<$r-.8 || $z<$d;

		    # $d is in the range 0,8 (scaling by 4/pi)
		    # this allows us to draw only an arc of a circle,
		    # instead of the full thing (hence the ``c'' and
		    # the tops of the ``m''s)
		    $d=atan2($y-$v, $x-$u) / atan2(0, -1) *4 +4;
		    next if $d<$k || $l<$d
		}
		# replace item at position $_/2 with a * (remember that
		# $_ is going to twice the width of the screen)
		substr $@, $_/2, 1, '*'
	    }
	}
	# on every second line, append the contents of $# (our output)
	# with $@.$/ ($/ is a "\n" by default).
	$| || ($#.=$@.$/)
    }
    print $#
}
