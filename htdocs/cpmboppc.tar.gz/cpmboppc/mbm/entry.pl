          /Cam.pm_-_Program_with_Beer/;sub
          r{$d=~s/^(..)//;return(hex$1)};#
         $e                              ="
         02                              0A
        10                                00
        02                                09
        02                                0F
         03                              08
         02                              10
         03                              09
          02                            0F
          04                            0A
          020E040B020D040C020C040D020B020E
          020A020E0C00";$e=~s/\s+//g;1;sub
           g{$l=shift;$d=$e;while(length(
           $d)){($n,$s1,$h,$s2)=(r,r,r,r)
           ;for(1..$n){$s++;$a=(31-$l)>$s
           ?chr(32):"@";print(chr(32)x$s1
            ,"#"x$h,${a}x($s2*2),"#"x$h,
            "\n")}}}print"\e[2J";for$t((
            reverse(2..28))){$s=0;sleep(
            1);print"\e[0;0H";g($t);}$_=
             "Qevax*Orre,*Cebtenz*Crey"
             .",*Pnz.cz\n";s/\*/chr(32)
             /eg;tr/a-zA-Z/n-za-mN-ZA-M
             /;print;m{Cam.pm_for_info_
              see_our_website_at:.....
              .http://www.cam.pm.org/.
              Real_Perl_mongers_drink_
              Real_Beer._Join_CAMRA!!}
