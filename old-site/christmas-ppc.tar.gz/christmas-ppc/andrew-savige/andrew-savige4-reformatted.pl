# The data for the bottom of the candle
$; = q]
       A"#,Z
       >1Z
       97Z
       5;Z
       5;Z
       5:Z
       5:Z
       5;Z
       4<Z
       3=Z
       3;Z
       3;Z
       68Z
       68Z
       68Z
       68Z
       68Z
       68Z
       68Z
       68Z
       $"28Z
       !*-8)"&"Z
       #.'8(+Z
       $1#8$2Z
       &^Z
       *##SZ
       0%$6-"Z
       ;-Z
       7/Z
       33Z
       13Z
       3$$$
      ];
$~ = 'Qivv}$Glvmwxqew';

sub _ {
    # get rid of the spaces in $_
    s}\s}}g;

    $. = '*';

    print join"", (!!system $^O =~ Win3 ? CLS : 'clear'),
		  (
		     # this map splits per line
		     map { 
			   # this one splits per character, and signals
			   # the run length
			   map ( ( ($.^=$/) x (-33+ord) ), m).)g ), $/
			 }
			 split+Z
		  ),
		  # @, contains the text for the Happy Christmas message
		  @,;
    ;

    # the /g makes sure that the next time, we retain our current position
    # so each time this is called, we push a new word, at the end, we push
    # a newline. The words are taken from $~
    push( +@, , $~ =~ /.*?\$/g ?
				 # the word themselves need to have 4
				 # subtracted from the ascii value of each
				 # character.
				 map { chr(-4 + ord) } $&=~ ((( m).)g )))
			       :
				 $/
	);

    # sleep 1
    sleep !$%
}

# the data for one of the tops

$: = q^
      B"Z
      6"("Z
      <"*"Z
      1"%"*"-"Z
      H"Z."'"("%"+"%"Z
      >#Z
      1"'"'$$"%"&"$"Z
      ,"3&Z
      3"+),"Z
      8"%*$"%"Z
      1",*Z
      >'#"$%Z
      7"%"%"&)Z
     ^;

# and the other

$^ = q^
       @"Z
       8"*"Z
       ="*"Z
       2"&"*"*"Z
       F"Z
       /"%")"&")"%"Z
       >#Z
       2"'"&$%"%"$"$"Z
       -"2&Z
       4"*)+"Z
       7"&*%"#"Z
       0"-*Z
       >'$"#%Z
       6"%"&"&)Z
      ^;
;;

$~ .= '$xs$e$wrs{fsyrh$geq2tq$jvsq$e$W}hri}$wyrfexliv%$';

# set autoflush
$|=1;

# get rid of the spaces in $~
$~ =~ s~\s~~g;

# run each individual top 6 times.
_( $_ = $: . $; ), _ $_ = $^ . $; , for !$% .. 6
