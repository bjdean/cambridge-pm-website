$_ = q~
       vZ
       vZ
       &%('$&"'"&(&"&$&"'"&$Z
       $#$$$#$%$&"'"&(&#%$&"'"&#Z
       #$$$#%#%$%$%$%(%%%#%$%$%#Z
       "%*#$%$%$%$%(%%%#%$%$%#Z
       "%,($%$%$%(%%%#%$%$%#Z
       "%*%"%$%$%$%(%%%#%$%$%#Z
       #%%"#%#%$%$%$%$##&#%$%$%$%#Z
       $&""$%"&$%$%$%#%"%"&%%$%$%#Z
       %&%&#%"'"'"'###%*'"'"'"Z
       T%?Z
       T%?Z
       S'>Z
       v
      ~;
s;\s;;g;

# the following bit of code is basically:
#  @, ends up containing the cam.pm text, which is extracted from the RLE
#     data in $_
#  @; is filled with snow on 30 rows
#  each frame is printed in the map, which prints the current "@;" (screen)
#  the splice then takes off a row of snow and turns it into the cam.pm
#     body.
#  finally a newline is pushed on at the top.
$; = '
      @, = map { $.=$" ; join "" , map((($.^=O)x(-33+ord)),/./g) , $/ }
                  split +Z;

      s/./(rand)<.2 ? "o" : $"/eg for @; = ((5x84).$/)x30;

      map { system $^O =~ W ? CLS :"clear" ;
            print @;
            ;
            splice @; , -$_ , 2 , pop @, ;
            @; = ( $/ , @; );
            sleep !$%
          } 2..17
     ';

# eval the above code with no spaces in it.
$; =~ s;\s;;g;
eval $;
