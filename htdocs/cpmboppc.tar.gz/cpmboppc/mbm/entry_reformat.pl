sub r {
    $d=~s/^(..)//;
    return(hex$1)
}

$e="020A1000
    0209020F
    03080210
    0309020F
    040A020E
    040B020D
    040C020C
    040D020B
    020E020A
    020E0C00";

$e=~s/\s+//g;

sub g {
    $l=shift;
    $d=$e;
    while(length($d)) {
	($n,$s1,$h,$s2)=(r,r,r,r);
	for(1..$n) {
	    $s++;
	    $a=(31-$l)>$s?chr(32):"@";
	    print(chr(32)x$s1,"#"x$h,${a}x($s2*2),"#"x$h,"\n")
	}
    }
}

print"\e[2J";

for$t((reverse(2..28))) {
    $s=0;
    sleep(1);
    print"\e[0;0H";
    g($t);
}

$_="Qevax*Orre,*Cebtenz*Crey,*Pnz.cz\n";

s/\*/chr(32)/eg;
tr/a-zA-Z/n-za-mN-ZA-M/;
print;
