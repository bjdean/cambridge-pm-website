            sub                          l{$
          r[-1]=~                      s/./-/g
         ;a(   2,$d  );a(4,"/$e\\")  ;a(3   ,$f
          );a(5,$u.$e.    "".$    u."",1);for(
          @t){$p="(.{"    .$_.    "}";$r[-5]=~
         s,  $p.)   .,$    1.    "."   ,ex;  $r
        [0-    $_]   =~s;  $p  )...   ;$1    .""
       ."/$u"   .qq/\\/;xe ,1 for(2..4)}   $_=$z.
      ""     .join"\n",@r;print;sleep$|}sub     r{
  int(rand$_[0])}$|=1;$u=$";$e="_"x5;$a=$u."o";$b="o";
 ;sub  a{;substr  $r[-$_[0    ]],$h,7,  $_[1]}sub  t{t(
 01)    if!@_;$    k=$a;$      a=$b;$    b=$k;$r    [$_
 -01]  =~s/$a/r(  012)?$a:    $b.""/eg  for(1..$r  )}$b
  .=$u;$z="\e[H\e[J";($r,$c)=split/\s/,`stty${u}size`;
      $v     =$"x$c;$h=r($c-7);@t=map{r($c-     3)
       }(0..r   (9));$k=$b ;$ k=~s/\s//;   for(01
        ..$    r){   ($r[  $_  -1]=   $v)    =~#
         s,  \s,r   (30    )?    $":   $k#"  o"
          ,xeg}($f=$d=    "|".    "$u#$u+$u|")
          =~y/#/+/;for    (0..    $r){l;t;@r=(
         $v,   @r);  pop@r}$r[-6]="  Let"   .$"
          ."it$u"                      ."snow"
            ;l;                          $p;
