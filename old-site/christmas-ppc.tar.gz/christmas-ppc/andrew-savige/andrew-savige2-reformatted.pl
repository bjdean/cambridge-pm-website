# Set up $_ to be our data string. This means that all of the // operations
# will work sensibly.

# The data has been reformatted as the next operation removes all \s
# characters. I feel this is ok to aid the readability of this program.
$_='3301Z
    21010701Z
    27010901Z
    1601040109011201Z
    3901Z
    130106010701040110010401Z
    2902Z
    1601060106030301040105010301Z
    11011805Z
    180110081101Z
    2301040903010401Z
    16011109Z
    290602010304Z
    2201040104010508Z
    32010211Z
    2916Z
    2422Z
    2026Z
    2026Z
    2025Z
    2025Z
    2026Z
    1927Z
    1828Z
    1826Z
    1826Z
    2123Z
    2123Z
    2123Z
    2123Z
    2123Z
    2123Z
    2123Z
    2123Z
    2123Z
    03011723Z
    0009122308010501Z
    0213062302010410Z
    031701230317Z
    030203360220Z
    090202120335Z
    1504041601030102030105010501Z
    160109060105Z
    2214Z
    1818Z
    1618Z
    180302030303Z';

# get rid of the spaces in the data.
s/\s//g;

# set $f to be "*". Worth noting at this point that "*" ^ "\n" = " ".
$f='*';

;;;;

# take off two characters from the stream (so we get double figures)
# and use them to alternately print spaces and "*"s (because of the
# XOR property above. Do this for each of the parts in between split/Z/
# Note that there are 3 different uses of $_ here. In the outside, the
# full data string, then the part in the for() loop that's split by the
# "Z" characters, then the current 2 numbers in the map. This is fine
# because they're implicitly localised at each level.
print +map ( ( ( $f ^= $/ ) x (($_)) ), /../g), $/
    for ((((((((((((((((((((((((((((((((((((
	# worth noting at this point that "+" stringifies the bareword
	# so this is morally equivalent to ``split/Z/''
	split+Z
	))))))))))))))))))))))))))))))))))))
