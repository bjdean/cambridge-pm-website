          #Please_Turn_Off_Text_Buffering#
          print"\e[H\e[J";$a=$b=$n=$m=#sfb
         10                              ;#
         $_                              ="
        "#                                #"
        ."                                "#
        ."                                #"
         ;#                              "|
         $#                              =#
         $_                              x#
          24                            ,#
          $c                            =#
          $d=.03;for(;;++$->5**4?$-=0:do{#
          (select$_=chr(1),"","",0)[0]||#$
           next;sysread(STDIN,$_,1)}){/k/
           ?$n-=($n>5):/a/?$m-=($m>5):/s/
           ?$m+=($m<69):/l/?$n+=($n<69):1
           ;(($a+=$c)<2and$a=2)|($a>72and
            $a=72)and$c=-$c;($b+=$d)<1&#
            abs($a-$m)<4and$b=1.1,$d=-$d
            ,$c+=($a-$m)/50;$b>23&abs($a
            -$n)<4and$b=22.9,$d=-$d,$c+=
            ($a-$n)/50;$c*=0.9while#Pong
             abs($c)>.09;$b>=1&$b<23or#
             die;substr(($o=$#),1698+$n
             ,8)="~k~~~~l~";substr($o,#
              int($b)*74+$a,2)="()";#$
              substr($o,$m-4,8)="_a__"
              ."__s_";print"\e[;H$o"};
