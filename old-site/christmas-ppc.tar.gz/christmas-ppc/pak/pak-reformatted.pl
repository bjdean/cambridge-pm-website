# for each character in:
# C3Q3!A7M7!93342E2433!AC444C!AC444C!92243342433422!83433422243343!763
# A121A36!625U52!2k!142928482924!134746664743
# do:
for ((), split +'', ('C' . '' . '3' . 'Q3!A7M7!93' . '3' . '4' . '2E2433!A' .
		     'C4' . '44C!AC444' . 'C!922433' . '42' . '433422!8' .
		     '' . '' .  '' . '' . '' . '' . '' . '' . '' . '' . ''
		     . '' . '3' . '' . '433' . '422243' . '' . '343!763' .
		     'A1' . '' . '21A36!625U52!2k!1429284829' . '' .
		     '24!134746664743'
		     )) {
# if the character is a "!" then print a newline
$t.=$/ , next , if "!" eq $_;
# otherwise, it's a space or hash (switching) for
# (if it's a number, that number, otherwise the ascii value - 55)
# characters
$t.=( $|-- ? '#' : chr(32) ) x ( ord $_ > 57 ? ( -55 + ord $_ ) : $_ );
}

# we now have a representation of the top half of the snowflake in #'s

;

# @l contains the lines of our now expanded template.
@l=((split "\n", ($t)));

# $nn contains the number of lines
$nn=@l;

();

# mirror all but the last line on the end of the array, going outwards.
push  @l, $l[$nn-$_] for(2..@l);

# at this point, join("\n",@l) would have a full snowflake layout.

;

# set our record separator to undef, so when we do <> it will read the
# entire file.
undef($/);

# get each line of the file into @p, converting all the non-whitespace to
# "#"
@p=map {s/[^\s]/#/g ; $_} split "\n", <>;

# generate numbers to the bigger of @l and @p
foreach (0..(@l>@p?@l-1:$#p)) {
    # split the iteration line of the template into characters, making sure
    # to cope in the case where it's undefined.
    @a=split '', $l[$_] || '';

    ;

    # do the same for the line of the input. the $_." " is a pointless
    # stringification and then back again, but it uses up characters and
    # whitespace.
    @b=split '', $p[$_." "] || "";

    # for the bigger of a and b (note that we have these loaded and the
    # $_ is localised. iterate for that number of characters.
    for(0 .. (@a>@b ? $#a : $#b )) {
	# $c will contain the value at this point of the template, or if
	# it's not there then a space - this copes with trailing whitespace.
	$c=$a[$_] || chr(32);

	;
	;

	# similarly for $d and the input
	$d=$b[$_] || chr(32);

	;
	;
	;
	;
	;

	# print the appropriate character, the value from the template if
	# they are the same, a "-" if $c thinks there should be whitespace
	# and a "+" if $c thinks there should be text.
	print +($c) eq $d ? $c : chr(32) eq ($c) ? "-" : "+"
    }
    # this is a useless substitution, since $_ is a number at this point.
    s;#   ;;g;

    # we've reached the end of the line, so print the newline.
    print "\n"
}
