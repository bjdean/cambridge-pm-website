$_ = q~
       vZ
       vZ
       &%('$&"'"&(&"&$&"'"&$Z
       $#$$$#$%$&"'"&(&#%$&"'"&#Z
       #$$$#%#%$%$%$%(%%%#%$%$%#Z
       "%*#$%$%$%$%(%%%#%$%$%#Z
       "%,($%$%$%(%%%#%$%$%#Z
       "%*%"%$%$%$%(%%%#%$%$%#Z
       #%%"#%#%$%$%$%$##&#%$%$%$%#Z
       $&""$%"&$%$%$%#%"%"&%%$%$%#Z
       %&%&#%"'"'"'###%*'"'"'"Z
       T%?Z
       T%?Z
       S'>Z
       v
      ~;

# get rid of the spaces in $_
s;\s;;g;

$~=q~
     Z
     Z
     Z
     J_#_Z
     H/'\\Z
     G|#o#o#|Z
     G|$<%|Z
     H\\"\\!_!_!/"/Z
     G/)\\Z
     F/+\\Z
     E|-|Z
     E|-|Z
     E|-|Z
     F\\+/Z
     G\\)/
    ~;
;

# Fill @x and @, with the RLE encoded "cam.pm" block from $_
@x = @, = +map {
		$. = $";
		;
		join "", map( ( ( $. ^= O ) x (-33+ord) ), /./g )
	       } split +Z;

# get rid of the spaces in $~ (the snowman)
$~ =~ s~\s~~g;
;

# fill @; with snow
s/./(rand)<.2?"o":$"/egx for @; =(5x84)x30;

# run our frames
map {
     # clear the screen
     system $^O =~ W ? CLS : +"clear";
     ;;;

     # print "$_\n"
     print $_ . $/,, for $_-18 ?
				 # the snowscape
				 @;
			       :
				 ((
				 # this map draws the snowman
				 map {
				     $| = 1;
				     ;;;
				     join "",
				       # alternate characters are RLE number
				       # of spaces, or the character itself
				       map( $|-- ? $" x (-3*11+ord) : $_, /./g)
				     } split +Z, $~),
				       # @x contains the block
				       @x);
     # advance the snowscape pushing the snow and block
     splice @; , -$_ , 2 , pop @, ;
     @; = ( "" , @; );
     ;;;
     # sleep
     sleep !$%
    } +2..18
