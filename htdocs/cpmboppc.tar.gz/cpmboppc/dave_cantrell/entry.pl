          $foo='$spc=chr(32);$pi&=&4*atan2
          (1,1);$radius=6367000;sub&deg2ra
         d{                              $_
         [0                              ]*
        $p                                i/
        18                                0}
        su                                b&
         ac                              os
         {a                              ta
         n2                              (s
          qr                            t(
          1-                            $_
          [0]*$_[0]),$_[0])}($l1,$l3)=&dms
          2degs(shift);($l2,$l4)=&dms2degs
           (shift);printf("%8d${spc}km\n"
           ,distance($l1,$l3,$l2,$l4)/100
           0);printf("%8d${spc}miles\n",d
           istance($l1,$l3,$l2,$l4)/1609.
            344);sub&distance{$radius*ac
            os(sin($_[0])*sin($_[2])+cos
            ($_[0])*&cos($_[2])*cos($_[1
            ]-$_[3]));}sub&dms2degs{$_[0
             ]=~/(\d?\d\d):(\d\d):(\d\d
             )([NS]),(\d?\d\d):(\d\d):(
             \d\d)([EW])/i;deg2rad(($1+
             $2/60+$3/3600)*(($4eq"N")?
              1:-1)),&deg2rad(($5+$6/6
              0+$7/3600)*(($8eq"E")?1:
              -1));}';$foo=~s/\s//gi;$
              foo=~y/&/\t/;eval($foo);
