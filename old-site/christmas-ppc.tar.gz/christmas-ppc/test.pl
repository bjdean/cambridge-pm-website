#!/usr/bin/perl

open(LAYOUT,"layout") || die "Couldn't open \"layout\": $!\n";
open(FILE,$ARGV[0]) || die "Couldn't open \"$ARGV[0]\": $!\n";

my $finished = 0;

while(!$finished) {
    $layout=<LAYOUT>;
    $file=<FILE>;
    (defined($layout) && defined($file)) || ($finished=1);
    $layout="" unless defined $layout;
    $file="" unless defined $file;

    $layout=~s/\s*$//;
    $layout=~s/^([^\t]*)\t/$1 . " "x(8-(length($1)+8)%8)/e while($layout=~/\t/);
    $layout=~s/#/\\S/g;
    $file=~s/\s*$//;
    $file=~s/^([^\t]*)\t/$1 . " "x(8-(length($1)+8)%8)/e while($file=~/\t/);
    die("Template doesn't match") unless $file=~/^$layout$/;
}
close(LAYOUT);
close(FILE);
print "Everything was OK\n";
