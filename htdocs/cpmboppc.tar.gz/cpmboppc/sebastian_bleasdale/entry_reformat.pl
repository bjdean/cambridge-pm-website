# clear the screen
print"\e[H\e[J";
$a=$b=$n=$m=10;
$_="\n                                   ".
   "                                     #";

# work out our playing area (contained in $#)
$#=$_ x24;

$c=$d=.03;

# this bit is complicated. after every iteration of the loop, add 1 to
# $- (starts at 0) if it reaches 625 then reset it. otherwise select on
# STDIN, and if there is something to read, then read it.
for( ; ;
    ++$->5**4 ?
	$-=0 :
	do {
	    (select$_=chr(1),"","",0)[0] || next;
	    sysread(STDIN,$_,1)
	}
    ) {
    # $a is the horizontal position of the ball
    # $b is the vertical position of the ball
    # $c is the horizontal velocity of the ball
    # $d is the vertical velocity of the ball
    # $_ contains the current keystroke, if there is one or a ^A if not.

    # this makes the most sense written out like this, and handles the
    # keystroke as necessary
    /k/?$n-=($n>5):
    /a/?$m-=($m>5):
    /s/?$m+=($m<69):
    /l/?$n+=($n<69):1;

    # bounce it at left and right if necessary with the side effect of
    # moving the ball with the ($a+=$c)
    # the (a and b) construction is just an expanded $a<=2 and $a>=72
    # the bitwise or is like a logical or.
    (($a+=$c)<2 and $a=2) | ($a>72 and $a=72) and $c=-$c;

    # bounce it at the top if necessary (with the side effect of moving
    # the ball with the ($b+=$d))
    ($b+=$d)<1 & abs($a-$m)<4 and $b=1.1, $d=-$d ,$c+=($a-$m)/50;

    # bounce it at the bottom if necessary
    $b>23 & abs($a-$n)<4 and $b=22.9, $d=-$d, $c+=($a-$n)/50;

    # make sure it doesn't fly off wildly to the side.
    $c*=0.9 while abs($c)>.09;

    # make sure the ball is in the playing area.
    $b>=1 & $b<23 or die;

    # draw out the current playing area.
    # first the player two bat: 1698=(23*74)-4
    substr(($o=$#),1698+$n,8)="~k~~~~l~";
    # then the ball
    substr($o,int($b)*74+$a,2)="()";
    # then the player one bat
    substr($o,$m-4,8)="_a____s_";

    # reset the cursor, and draw the playing area
    print"\e[;H$o"
};
