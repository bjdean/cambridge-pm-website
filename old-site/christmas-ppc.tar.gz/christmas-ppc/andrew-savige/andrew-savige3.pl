            $:=                          q^A
          "#,Z>1Z                      97Z5;Z5
         ;Z5   :Z5:  Z5;Z4<Z3=Z3;Z3  ;Z68   Z68
          Z68Z68Z68Z68    Z68Z    68Z68Z$"28Z!
          *-8)"&"Z#.'8    #"%+    Z$2"8$2Z$#$E
         #5  Z*##   -$D    Z0    %%1   "$"#  $"
        &"&    "Z1   "*'"  &Z  7/Z3   3Z1    3Z3
       $#$$$Z   ^;$;=q^B"Z 6" ("Z<"*"Z1"   %"*"-"
      ZH     "Z."'"("%"+"%"Z>#Z1"'"'$$"%"&"     $"
  Z,"3&Z3"+),"Z8"%*$"%"Z1",*Z>'#"$%Z7"%"%"&)Z^;$^=q^@"
 Z8"*  "Z="*"Z2"  &"*"*"ZF    "Z/"%")"  &")"%"Z>#  Z2"'
 "&$    %"%"$"$    "Z-"2&      Z4"*)+    "Z7"&*%    "#"
 Z0"-  *Z>'$"#%Z  6"%"&"&)    Z^;;;sub  _{s}\s}}g  ;$.=
  '*';system$^O=~Win?CLS:'clear';print+map((($.^=$/)x(
      ((     ord))-33)),/./g),$/for+split+Z     ;;
       sleep!   $%}_($_=$; .$ :),_$_=$^.   $:,for
        !$%    ..4   ;$_=  'M  erry   60C    hri
         st  mas6   0to    60    a60   snow  bo
          und60cam.pm6    0fro    m60a60Sydney
          60sunbather!    ';$\    =$/;s;\s;;g;
         ;;;   s;$=  ;$";gsex;print  ;s;k   ara
          te;chop                      ;eggs;;
            #by                          /-\
