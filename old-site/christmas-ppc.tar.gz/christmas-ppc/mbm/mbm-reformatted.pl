# This function is better called "render"
sub l {
    # set out the base.
    $r[-1] =~ s/./-/g;
    ;

    # set out the house
    # at this point, $d is "| # + |"
    #                $f is "| + + |"
    #                $e is  "_____"
    a(2, $d);
    a(4, "/$e\\");
    a(3, $f);
    a(5, $u . $e . "" . $u . "", 1);

    # set out the trees
    for(@t) {
	$p="(.{".$_."}";
	$r[-5] =~ s,$p.).,$1.".",ex;
	$r[0-$_] =~ s;$p)...;$1.""."/$u".qq/\\/;xe,1 for(2..4)
    }

    # $_ contains the screen, including the "clear screen" code
    $_=$z . "" . join "\n", @r;

    print;

    # $| is set to 1 so this is a "sleep 1"
    sleep $|
}

# r() returns a random integer between 0 and <arg>-1
sub r {
    int(rand $_[0])
}

# set autoflush
$|=1;

# $u and $" both contain ' ' by default.
$u=$";

# $e now contains "_____"
$e="_" x 5;

# $a will contain " o"
$a=$u . "o";

# $b contains "o"
$b="o";
;

# this is a replace specifically for drawing the house.
# it does a substitution for the line <arg1> from the bottom
# position $h for 7 characters with <arg2>
sub a {
    ;
    substr $r[-$_[0]], $h, 7, $_[1]
}

# this function is better called perturb. It occasionally swaps " o" for "o "
# and vice versa. It does this recursively, by calling itself with an
# argument.
sub t {
    # recurse if we haven't already
    t(01) if ! @_;
    # swap $a and $b
    $k=$a;
    $a=$b;
    $b=$k;
    # do the swap across all the rows for whatever is in $a with $a or $b
    # on a 1 in 10 chance.
    $r[$_-01] =~ s/$a/r(012) ? $a : $b . ""/eg for(1..$r)
}

# $b="o ";
$b.=$u;

# this is the clear screen code
$z="\e[H\e[J";

# get the number of rows and columns rows => $r and cols => $c
($r,$c) = split/\s/, `stty${u}size`;

# $v contains a blank line as wide as the screen.
$v=$" x $c;

# $h is the left-hand position of the house
$h=r($c-7);

# @t contains the left hand positions of the trees there are between 1 and 9
# of them and they're each random
@t=map {r($c-3)} (0..r(9));

# set up $k="o "
$k=$b;
# $k="o"
$k=~s/\s//;

# for each row on the screen, set it to a blank line, and then randomly
# (1 in 30 chance) put snow in each position instead.
for(01..$r) {
    ($r[$_-1]=$v) =~ s,\s,r(30) ? $" : $k,xeg
}

# $f is "| + + |"
# $d is "| # + |"
($f=$d="|" . "$u#$u+$u|") =~ y/#/+/;

# run the frames
for(0..$r) {
    # draw the frame
    l;

    # perturb the snow
    t;

    # get the next frame, by putting a blank line at the top, and
    # removing the bottom line
    @r=($v, @r);
    pop @r
}

# set $r[-6] to "  Let it snow"
$r[-6]="  Let" . $" . "it$u" . "snow";

# render the frame
l;

# space filler.
$p;
