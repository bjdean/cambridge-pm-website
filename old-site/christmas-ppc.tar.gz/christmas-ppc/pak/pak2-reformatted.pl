# + and ~~ are noops in this (~~ because you get "bitwise complement
# of bitwise complement")
$t = '3' . '*A*' . '!1.=' . '.' . '!' . '0**+)5)+**' . '!' . '1' .
     '3+++3!13' . '++' . '+3!0))+**' . '+)+**+))' . '!/' .
     '*+**+)))+' . +'*' . '*' . +'+' . '*' . +'!' . ~~'.-' . +'*1' .
     ~~'(' . ')(1' . '*-!-),E' . +',)!)[!(+' . ')0)' .
     +'/+/)0)+!(*+.+---+.+*!';

# $w is " "
$w=chr 32;

# in the above string substitute every character for either
#   \n if it is a "!"
#   run of alternate "#" and " " to the ascii value of the character
#     minus 39
# $t therefore contains the top half of template after this.
$t =~ s;.; $& =~ /!/ ? $/ : ($|--?'#':$w) x (-39 + ord $&) ;eg;

# $n is "\n"
$n= +$/;

# set $/=undef
$/=$1;

# <> will be the whole file ($/==undef)
# split it per line
# translate all of the nonwhitespace characters into "#", returning
# all of the lines (I can't see a situation where ~y~    ~#~c+23 is
# false)
@p=grep{~y~    ~#~c+23} split+$n, <>;

;

# @l is the template version of the above, being also split on \n
#    (~~$n eq "\n")
@l = split ~~$n , $t;

# reflect the template about its midpoint
push @l, $l[10-$_] for (-0..012);

# $s is going to be our output
# So for each line or the whole of the input (whichever is greater)
for(0...( 23 > @p ? +23 : $#p ) ) {
    # @a contains the characters on this line from the template
    +@a = split '', $l[$_] || '';

    # @b contains the characters on this line from the input
    @b = split '', $p[$_] || '';

    # for each character on the longest line.
    for(0...(@a > +@b ? $#a : $#b)) {
	# $c is the character from the template on this line, or
	#    a whitespace if it doesn't exist
	$c = $a[$_] || $w;

	# $d is the character from the input on this line, or
	#    a whitespace if it doesn't exist
	$d = $b[$_] || $w;

	# The above code makes sure that trailing whitespaces work.

	# This code puts the template character if both are the same
	# (ie " " or "#", and a "-" if they're different and the template
	# says whitespace, or a "+" if they're different and the template
	# has a "#"
	$s .= +$c eq $d ?
			  $c
			: 
			  ($w) eq $c ?
				       +'-'
				     :
				       ~~'+'
    }
    # add a newline to our output before processing the next line.
    $s .= $n
}

# $m is the output then "Errors:" and a count of the number of "+" and "-"
# characters in $s and then a newline.
$m = $s . +'E' . 'r' . +'r' . 'o' . +"rs:" . $s =~ +y.+-.    . . $n;
# print it.
print $m
