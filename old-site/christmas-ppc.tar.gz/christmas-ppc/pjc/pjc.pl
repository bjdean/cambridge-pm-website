            $w=                          100
          ;$w*=5;                      ;$W=$w*
         $w;   q--;  $p=atan2(1,0)*  2;3;   @P=
          ("\000"x3)x(    $W);    BEGIN{$";sub
          S{$_.='fhoq'    }sub    K{$_.='s'.((
         $n  ++))   .((    ''    .''   .'{'  ))
        ;};    sub   Y{$_  .=  $_[0   ]};    S;K
       ;Y(''.   '$k/=2;$'. '' .'l/=2}');   S;K;0;
      Y(     '$k/=3;$l/=3;$k+=$j/4}fhoqh{'.     ''
  .'cevq"P6\a$jq$j\a255\a",q@P}');S;K;Y('$g=$c/3;e}');
 S;K;  Y(q.$g=$.  .'c/-3;'    .'e}');S  ;K;Y('$'.  'g'.
 '='    .'$c*2'    .'/3}'      );;s/v    /vag/x;    sub
 p{$P  [$x+$w/2+  int($y)*    $w+$W/2]  ="\377"x3  }sub
  r{$z=$x*cos($t)+$y*sin($t);$y=$x*sin($t)-$y*cos($t);
      $x     =$z};tr/a-z/n-za-m/;s/d/$"/gx;     $x
       ++;$y=   4;eval$_}; s/ /japh/;sub   T{;$a= 
        $_[    0];   ;$b=  ((  $a&(   ($a    |(+
         $a  <<1)   )<<    1)    )>>   2)|(  $a
          >>3);if($b){    $_[0    ]=""}else{$_
          [0]="f$a;p;"    }};;    for(1..20000
         *10   ){$_  =int(rand(20))  ;T$_   ;0;
          eval$_}                      u#byPJC
            #JA                          PH#
