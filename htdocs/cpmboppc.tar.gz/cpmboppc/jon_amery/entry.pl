          open(S,"stty\040size\040|");$_=#
          <S>;/(\w*)#cam.pmBFOPerlPContest
         \W                              (#
         \w                              *)
        /x                                ;#
        $s                                =#   
        $1                                <(
         $2                              -1
         )/                              2?
         $1                              *2
          :#                            :)
          $2                            -1
          ;$si="\e[0;3";$sij="\e[1;3";@st=
          ($si."1m",$si."2m",$si."3m",$si.
           "4m",$si."5m",$si."6m",$si.###
           "7m",$sij."0m",$sij."1m",$sij.
           "2m",$sij."3m",$sij."4m",$sij.
           "5m",$sij."6m",$sij."7m");for(
            ;$a<$s/2;$a++){print"\n";for
            ($b=0;$b<$s;$b++){$r=0;$c=0;
            for($d=0;$d<@st;$d++){$nr=$r
            *$r-$c*$c;$c=2*$r*$c+$a*(5/#
             $s)-1.25;$r=$nr+$b*(2.5/$s
             )-2;if($r*$r+$c*$c>4){#JDA
             print((@st)[$d]."@");last;
             }}if($d==@st){print$si.###
              "0m@";}}}$_=<>;#Best.run
              #in.an.ANSI.colour.term#
              ##as.large.as.possible##
              #Press<return>to.finish#
