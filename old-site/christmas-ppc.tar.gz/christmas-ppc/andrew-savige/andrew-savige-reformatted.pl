# STAGE 1 : run through Deparse
#
# '?' =~ m[(?{eval"open\$%;\@~=map\{y;!-~;.;;\$_\}<0>;map\{`clear>&2`; warn\$/x(\$_+\$_),\@~; sleep!\$%\}\$% .. 9"})];
#
# STAGE 2 : reduce by getting rid of the eval (it's the only thing that
#           is run by the regexp eval, and doesn't return anything)
# this is a function of the way that EyeDropper works. In effect, it's
# a null regexp and an eval within the regexp. The string you see above
# and below is formed by doing bitwise operations on constant strings.
'?' =~ m[(?{
    # the following line is equivalent to:
    #  open 0, $0;
    open $%;

    # map yourself ($0) translating all the characters to "." as we go into
    # the array @~
    @~ = map { y;!-~;.; ; $_ } <0>;

    # equivalent to a "for (0..9) {"
    map {
	# clear the screen
	`clear >&2` ;

	# print out 2n "\n"s (the value of $/) and then our translated
	# snowflake
	warn $/ x ($_+$_), @~;

	# sleep 1 (1 is the !0 and $%==0)
	sleep !$%
    } $%..9

    # end our eval
    })];
